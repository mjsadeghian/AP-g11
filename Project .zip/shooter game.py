import pygame
import sys
import login
import random
def start_game(player1_name, player2_name):
    pygame.init() #shoroo pygame
    pygame.display.set_caption('Shooter')
    screen = pygame.display.set_mode((840 , 400))  # safhe default
    screen.fill('white')
    Clock = pygame.time.Clock() 
    Surface = pygame.image.load('field.jpg') #background
    pygame.display.update()
    Clock.tick(60)
    BLUE = (0,0,255) # rang aabi baraye tir
    BLACK = (0,0,0) # rang siyah baraye target
    font = pygame.font(None , 16)


    class Player:
        # etelaat basikon
        def __init__(self, name , color, time , score , bullet):
            self.name = name
            self.color = color
            self.time = time
            self.score = score
            self.bullet = bullet
            self.last_successful = False
        def situation(self,x,y):
            # mogheit haye tir ha dar lahze
            message = font.render(f'player: {self.name} , color = {self.color} , time = {self.time} , bullets = {self.bullet} , score = {self.score} ' , False , 'red')
            block = message.get_rect(center = (x,y))
            screen.blit(message , block)
    class Bullet:
        # tir ha
        def __init__(self,x,y,color):
            self.x = x
            self.y = y
            self.block = pygame.Rect(x,y,6,6) # x , y  mogheit haa, 6 , 6 size
            self.color = color
        def draw(self,screen):
            pygame.draw.rect(screen,self.color,self.block)
    class Cible: # target
        def __init__(self,image_path,size = (50,50)):
            self.image= pygame.image.load(image_path).convert_alpha()
            self.image = pygame.transform.scale(self.image, size)    
            self.block = self.image.get_rect(center = (random.randint(20,820), random.randint(20,380)))
    class Trophy(Cible): #target ha be shekl jaam
        def __init__(self):
            super().__init__('trophy.png')
        
def main():
    first = login.LoginSignupApp(1) # login basikon aval
    success1 , player1_name = first.run()
    if not success1:
        pygame.quit()
        sys.exit()
    while True:
        # login nafar dovom
        second = login.LoginSignupApp(2)
        success2 , player2_name = second.run()
        if not success2:
            pygame.quit()
            sys.exit()
        if player1_name == player2_name: # esm ha nabayad yeki bashand
            print('Names cant be the same please try again')
        else:
            break
    start_game(player1_name , player2_name)
if __name__ == "__main__": # dar halat defult code login ejra shavad
    main()