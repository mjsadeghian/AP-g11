import pygame
import sys
import login
import random
def start_game(player1_name, player2_name):
    pygame.init() #shoroo pygame
    pygame.display.set_caption('Shooter')
    screen = pygame.display.set_mode((840 , 400))  # safhe default
    screen.fill('white')
    Clock = pygame.time.Clock() 
    Surface = pygame.image.load('field.jpg') #background
    pygame.display.update()
    Clock.tick(60)
    BLUE = (0,0,255) # rang aabi baraye tir
    BLACK = (0,0,0) # rang siyah baraye target
    font = pygame.font(None , 16)


    class Player:
        # etelaat basikon
        def __init__(self, name , color, time , score , bullet):
            self.name = name
            self.color = color
            self.time = time
            self.score = score
            self.bullet = bullet
            self.last_successful = False
        def situation(self,x,y):
            # mogheit haye tir ha dar lahze
            message = font.render(f'player: {self.name} , color = {self.color} , time = {self.time} , bullets = {self.bullet} , score = {self.score} ' , False , 'red')
            block = message.get_rect(center = (x,y))
            screen.blit(message , block)
    class Bullet:
        # tir ha
        def __init__(self,x,y,color):
            self.x = x
            self.y = y
            self.block = pygame.Rect(x,y,6,6) # x , y  mogheit haa, 6 , 6 size
            self.color = color
        def draw(self,screen):
            pygame.draw.rect(screen,self.color,self.block)
    class Cible: # target
        def __init__(self,image_path,size = (50,50)):
            self.image= pygame.image.load(image_path).convert_alpha()
            self.image = pygame.transform.scale(self.image, size)    
            self.block = self.image.get_rect(center = (random.randint(20,820), random.randint(20,380)))
    class Trophy(Cible): #target ha be shekl jaam
        def __init__(self):
            super().__init__('trophy.png')
    class Extra_Bullet(Cible):
        def __init__(self):
            super().__init__('bullets.png')
        def collide(self, player):
            player.bullet += 5
    class Less_Bullet(Cible):
        def __init__(self):
            super().__init__('REDX.png')
        def collide(self, player):
            player.bullet -= 3
    class Extra_Time(Cible):
        def __init__(self):
            super().__init__('HotClock.png')
        def collide(self, player):
            player.time += 10
    class Less_Time(Cible):
        def __init__(self):
            super().__init__('ColdClock.png')
        def collide(self, player):
            player.time -= 5
    class Aim:
        # baraye shoot zadan
        def __init__(self, x , y , color):
            self.x = x
            self.y = y
            self.block = pygame.Rect(x , y , 5 , 5)
            self.color = color
        def shot(self, dx , dy):
            self.rect.x += dx
            self.rect.y += dy
    # info haye avalie
    Player1 = Player(player1_name , 'purple' , 60 , 0 , 10)
    Player1_last_pos = None
    Player2 = Player(player2_name , 'yellow' , 60 , 0 , 10)
    Player2_last_pos = None
    aim1 = Aim(random.randint(20,820) , random.randint(20 , 380) , 'purple')
    aim2 = Aim(random.randint(20,820) , random.randint(20 , 380) , 'yellow')
    trophy1 = Trophy() #target ha
    trophy2 = Trophy()
    trophy3 = Trophy()
    extra_bullet1 = Extra_Bullet() #item haye ezafe
    extra_bullet2 = Extra_Bullet()
    less_bullet1 = Less_Bullet()
    less_bullet2 = Less_Bullet()
    extra_time1 = Extra_Time()
    extra_time2 = Extra_Time()
    extra_time3 = Extra_Time()
    less_time1 = Less_Time()
    less_time2 = Less_Time()
    bullets = []
    aim1_shoot = False
    aim2_shoot = False
    extra_bullet1_value = True # value va zaher shodan item haye ezafe
    extra_bullet1_showvalue = False
    extra_bullet2_value = True
    extra_bullet2_showvalue = False
    less_bullet1_value = True
    less_bullet1_showvalue = False
    less_bullet2_value = True
    less_bullet2_showvalue = False
    extra_time1_value = True
    extra_time1_showvalue = False
    extra_time2_value = True
    extra_time2_showvalue = False
    extra_time3_value = True
    extra_time3_showvalue = False
    less_time1_value = True
    less_time1_showvalue = False
    less_time2_value = True
    less_time2_showvalue = False
    counter1 = 1 #talash ha
    counter2 = 2
    counter3 = 3
    counter4 = 4
    counter5 = 5
    counter6 = 6
    base_time = pygame.time.get_ticks()
    
    #baraye payan bazi
    def end_game():
        if (Player1.time == 0 or Player1.bullet == 0) and (Player2.time == 0 or Player2.bullets == 0):
            return True
        else:
           return False
    running = True
    while running:
        # baraye neshoon dadan makan tir ha
        for i in range(len(bullets) - 1 , -1 , -1):
            if bullets[i].color == Player1.color:
                Player1_last_pos = (bullets[i].x , bullets[i].y)
                break
        for i in range(len(bullets) - 1 , -1 , -1):
            if bullets[i].color == Player2.color:
                Player2_last_pos = (bullets[i].x , bullets[i].y)
                break
        for event in pygame.event.get():
            # baraye bastan bazi
            if event.type == pygame.QUIT:
                running = False
                sys.exit()
            if event.type == pygame.KEYDOWN:
                # baraye tekan dadan tir ha ba key ha
                if event.key == pygame.K_LEFT and aim1.rect.left - 8 > 0:
                    aim1.move(-8, 0)
                if event.key == pygame.K_RIGHT and aim1.rect.right + 8 < 840:
                    aim1.move(8, 0)
                if event.key == pygame.K_DOWN and aim1.rect.bottom + 8 < 400:
                    aim1.move(0, 8)
                if event.key == pygame.K_UP and aim1.rect.top - 8 > 20:
                    aim1.move(0, -8)
                if event.key == pygame.K_w and aim2.rect.top - 8 > 20:
                    aim2.move(0, -8)
                if event.key == pygame.K_s and aim2.rect.bottom + 8 < 400:
                    aim2.move(0, 8)
                if event.key == pygame.K_d and aim2.rect.right + 8 < 840:
                    aim2.move(8, 0)
                if event.key == pygame.K_a and aim2.rect.left - 8 > 0:
                    aim2.move(-8, 0)
                if event.key == pygame.K_TAB and Player2.bullet > 0 and Player2.time > 0:
                    aim2_shoot = True
                    Player2.bullet -= 1
                    bullets.append(Bullet(aim2.rect.x, aim2.rect.y, Player2.color))
                if event.key == pygame.K_SPACE and Player1.bullet > 0 and Player1.time > 0:
                    aim1_shoot = True
                    Player1.bullet -= 1
                    bullets.append(Bullet(aim1.rect.x, aim1.rect.y, Player1.color))

        hit_trophy1 = False
        hit_trophy2 = False
        # tashkhis barkhord tir ha be target ha
        for trophy in [trophy1, trophy2, trophy3]:
            if trophy.rect.colliderect(aim1.rect) and aim1_shoot:
                if Player1.last_shot_hit_trophy:
                    Player1.score += 2
                Player1.last_shot_hit_trophy = True
                hit_trophy1 = True
                trophy.rect.center = (random.randint(20, 820), random.randint(20, 380))
            if trophy.rect.colliderect(aim2.rect) and aim2_shoot:
                if Player2.last_shot_hit_trophy:
                    Player2.score += 2
                Player2.last_shot_hit_trophy = True
                hit_trophy2 = True
                trophy.rect.center = (random.randint(20, 820), random.randint(20, 380))
        if aim1_shoot and not hit_trophy1:
            Player1.last_shot_hit_trophy = False
        if aim2_shoot and not hit_trophy2:
            Player2.last_shot_hit_trophy = False

        # mantegh zaher shodan time ezafe
        if Player1.time < 40 and counter1 > 0:
            extra_time1_showvalue = True
            counter1 -= 1
        if Player2.time < 40 and counter2 > 0:
            extra_time2_showvalue = True
            counter2 -= 1
        if Player1.time < 20 and counter3 > 0:
            extra_time3_showvalue = True
            counter3 -= 1
        if Player2.time < 20 and counter4 > 0:
            extra_time4_showvalue = True
            counter4 -= 1

        # barkhord be time ezafe
        if extra_time1_showvalue and extra_time1_value and extra_time1.rect.colliderect(aim1.rect) and aim1_shoot:
            extra_time1.collied(Player1)
            extra_time1_value = False
            extra_time1_showvalue = False
        if extra_time1_showvalue and extra_time1_value and extra_time1.rect.colliderect(aim2.rect) and aim2_shoot:
            extra_time1.collied(Player2)
            extra_time1_value = False
            extra_time1_showvalue = False
        if extra_time2_showvalue and extra_time2_value and extra_time2.rect.colliderect(aim1.rect) and aim1_shoot:
            extra_time2.collied(Player1)
            extra_time2_value = False
            extra_time2_showvalue = False
        if extra_time2_showvalue and extra_time2_value and extra_time2.rect.colliderect(aim2.rect) and aim2_shoot:
            extra_time2.collied(Player2)
            extra_time2_value = False
            extra_time2_showvalue = False
        if extra_time3_showvalue and extra_time3_value and extra_time3.rect.colliderect(aim1.rect) and aim1_shoot:
            extra_time3.collied(Player1)
            extra_time3_value = False
            extra_time3_showvalue = False
        if extra_time3_showvalue and extra_time3_value and extra_time3.rect.colliderect(aim2.rect) and aim2_shoot:
            extra_time3.collied(Player2)
            extra_time3_value = False
            extra_time3_showvalue = False

    
        # mantegh time kamtar

        if Player1.time > 40 and counter1 > 0:
            less_time1_showvalue = True
            counter1 += 1
        if Player2.time > 40 and counter2 > 0:
            less_time2_showvalue = True
            counter2 += 1

        # barkhord be time kamtar
        if less_time1_showvalue and less_time1_value and less_time1.rect.colliderect(aim1.rect) and aim1_shoot:
            less_time1.collied(Player1)
            less_time1_value = False
            less_time1_showvalue = False
        if extra_time1_showvalue and extra_time1_value and extra_time1.rect.colliderect(aim2.rect) and aim2_shoot:
            less_time1.collied(Player2)
            less_time1_value = False
            less_time1_showvalue = False
        if less_time2_showvalue and less_time2_value and less_time2.rect.colliderect(aim1.rect) and aim1_shoot:
            less_time2.collied(Player1)
            less_time2_value = False
            less_time2_showvalue = False
        if less_time2_showvalue and less_time2_value and less_time2.rect.colliderect(aim2.rect) and aim2_shoot:
            less_time2.collied(Player2)
            less_time2_value = False
            less_time2_showvalue = False
        
        # mantegh zaher shodan tir ezafe
        if Player1.bullet <= 5 and counter5 > 0:
            extra_bullet1_showvalue = True
            counter5 -= 1
        if Player2.bullet <= 5 and counter6 > 0:
            extra_bullet2_showvalue = True
            counter6 -= 1

        # barkhord be tir ezafe
        if extra_bullet1_showvalue and extra_bullet1_value and extra_bullet1.rect.colliderect(aim1.rect) and aim1_shoot:
            extra_bullet1.collied(Player1)
            extra_bullet1_value = False
            extra_bullet1_showvalue = False
            
        if extra_bullet1_showvalue and extra_bullet1_value and extra_bullet1.rect.colliderect(aim2.rect) and aim2_shoot:
            extra_bullet1.collied(Player2)
            extra_bullet1_value = False
            extra_bullet1_showvalue = False
            
        if extra_bullet2_showvalue and extra_bullet2_value and extra_bullet2.rect.colliderect(aim1.rect) and aim1_shoot:
            extra_bullet2.collied(Player1)
            extra_bullet2_value = False
            extra_bullet2_showvalue = False
            
        if extra_bullet2_showvalue and extra_bullet2_value and extra_bullet2.rect.colliderect(aim2.rect) and aim2_shoot:
            extra_bullet2.collied(Player2)
            extra_bullet2_value = False
            extra_bullet2_showvalue = False
            

        # mantegh barkhord ba tir kamtar
        if Player1.bullet >= 5 and counter5 > 0:
            less_bullet1_showvalue = True
            counter5 += 1
        if Player2.bullet >= 5 and counter6 > 0:
            less_bullet2_showvalue = True
            counter6 += 1

        # por kardan safhe ba image haye emtiazat ezafe
        screen.blit(Surface , (0,0))
        if extra_time1_showvalue and extra_time1_value:
            screen.blit(extra_time1.image, extra_time1.rect)
        if extra_time2_showvalue and extra_time2_value:
            screen.blit(extra_time2.image, extra_time2.rect)
        if extra_time3_showvalue and extra_time3_value:
            screen.blit(extra_time3.image, extra_time3.rect)
        if extra_bullet1_showvalue and extra_bullet1_value:
            screen.blit(extra_bullet1.image, extra_bullet1.rect)
        if extra_bullet2_showvalue and extra_bullet2_value:
            screen.blit(extra_bullet2.image, extra_bullet2.rect)
        if less_bullet1_showvalue and less_bullet1_value:
            screen.blit(less_bullet1.image, less_bullet1.rect)
        if less_time1_showvalue and less_time1_value:
            screen.blit(less_time1.image, less_time1.rect)
        if less_bullet2_showvalue and less_bullet2_value:
            screen.blit(less_bullet2.image, less_bullet2.rect)
        if less_time2_showvalue and less_time2_value:
            screen.blit(less_time2.image, less_time2.rect)
        Player1.status(210, 10)
        Player2.status(210, 20)
        screen.blit(trophy1.image, trophy1.rect)
        screen.blit(trophy2.image, trophy2.rect)
        screen.blit(trophy3.image, trophy3.rect)
        for bullet in bullets:
            bullet.draw(screen)

        aim1_shoot = False
        aim2_shoot = False
        if end_game():
            # dar ooomadan as halghe
            running = False

        pygame.display.update()
        Clock.tick(60)

    # End game screen
    end = True
    while end:
        end_font = pygame.font.Font(None, 20)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                end = False
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_e:  # Exit
                    end = False
                    pygame.quit()
                    sys.exit()
                elif event.key == pygame.K_r:  # Restart
                    end = False
                    start_game(Player1.name, Player2.name)
                elif event.key == pygame.K_l:  # Back to login
                    end = False
                    main()
                
                
        #safhe payani
        screen.fill('white')
        end_image = pygame.image.load('graphics/end.jpg')
        end_image_rect = end_image.get_rect(center=(420, 200))
        screen.blit(end_image, end_image_rect)

        # bord bazikon aval
        if Player1.score > Player2.score:
            winner_text = end_font.render(f'{Player1.name} WON!\n{Player1.name} score: {Player1.score}\n{Player2.name} score: {Player2.score}', False, 'green')
            winner_text_rect = winner_text.get_rect(center=(420, 50))
            screen.blit(winner_text, winner_text_rect)
        # bord bazikon dovom
        elif Player1.score < Player2.score:
            winner_text = end_font.render(f'{Player2.name} WON!\n{Player2.name} score: {Player2.score}\n{Player1.name} score: {Player1.score}', False, 'green')
            winner_text_rect = winner_text.get_rect(center=(420, 50))
            screen.blit(winner_text, winner_text_rect)
        else:
            # mosavi
            winner_text = end_font.render(f'DRAW!\n{Player1.name} score: {Player1.score}\n{Player2.name} score: {Player2.score}', False, 'red')
            winner_text_rect = winner_text.get_rect(center=(420, 50))
            screen.blit(winner_text, winner_text_rect)

        end_txt = end_font.render('Press E to exit, R to restart, L to login', False, 'red')
        end_txt_rect = end_txt.get_rect(center=(420, 300))
        screen.blit(end_txt, end_txt_rect)
        pygame.display.update()





            
def main():
    first = login.LoginSignupApp(1) # login basikon aval
    success1 , player1_name = first.run()
    if not success1:
        pygame.quit()
        sys.exit()
    while True:
        # login nafar dovom
        second = login.LoginSignupApp(2)
        success2 , player2_name = second.run()
        if not success2:
            pygame.quit()
            sys.exit()
        if player1_name == player2_name: # esm ha nabayad yeki bashand
            print('Names cant be the same please try again')
        else:
            break
    start_game(player1_name , player2_name)
if __name__ == "__main__": # dar halat defult code login ejra shavad
    main()